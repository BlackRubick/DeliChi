import React from 'react'
import ReactDOM from 'react-dom/client'
import Login from './pages/Login'
import '../src/main.css'

ReactDOM.createRoot(document.getElementById('root')).render(
    <Login />
)
